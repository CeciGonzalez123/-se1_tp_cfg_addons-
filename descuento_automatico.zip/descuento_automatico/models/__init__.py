from . import descuento_automatico
