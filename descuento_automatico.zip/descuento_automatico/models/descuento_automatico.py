from odoo import models, fields, api

class DescuentoAutomatico(models.Model):
    _name = 'descuento.automatico'
    _description = 'Descuento Automático'

    name = fields.Char(string='Nombre del Descuento', required=True)
    descuento_porcentaje = fields.Float(string='Porcentaje de Descuento', required=True)

    @api.model
    def aplicar_descuento(self, order_id):
        order = self.env['sale.order'].browse(order_id)
        descuento = self.descuento_porcentaje / 100.0
        for line in order.order_line:
            line.price_unit = line.price_unit * (1 - descuento)
